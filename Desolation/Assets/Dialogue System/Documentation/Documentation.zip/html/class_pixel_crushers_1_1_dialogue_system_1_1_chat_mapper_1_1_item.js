var class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_item =
[
    [ "Fields", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_item.html#ad5b44aa493001659bfd1d43e15d9878a", null ],
    [ "ID", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_item.html#a34a3fe960df73c88555e0351d17a0158", null ]
];