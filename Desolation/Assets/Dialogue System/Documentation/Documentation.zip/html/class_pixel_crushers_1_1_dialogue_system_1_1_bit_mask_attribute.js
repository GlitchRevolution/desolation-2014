var class_pixel_crushers_1_1_dialogue_system_1_1_bit_mask_attribute =
[
    [ "BitMaskAttribute", "class_pixel_crushers_1_1_dialogue_system_1_1_bit_mask_attribute.html#a71189a377a9f9e4ff670f39bb2ad9967", null ],
    [ "propType", "class_pixel_crushers_1_1_dialogue_system_1_1_bit_mask_attribute.html#a5e021519141a792bdcc9693f78030a79", null ]
];