var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_conversation_controller =
[
    [ "alsoDisableDuringConversations", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_conversation_controller.html#a983ba195aa9d1c54d2855bc01ea37710", null ],
    [ "animationOnConversationStart", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_conversation_controller.html#ac6fa0210f2756b5de50927e715e237ef", null ]
];