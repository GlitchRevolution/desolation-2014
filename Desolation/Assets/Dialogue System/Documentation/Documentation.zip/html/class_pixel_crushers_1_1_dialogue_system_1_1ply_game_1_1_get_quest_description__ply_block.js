var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_description__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_description__ply_block.html#a7276196e90ad1d3572142d7fefc5646b", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_description__ply_block.html#a3ef26411b12d97d30cb33f539d1f7ef8", null ],
    [ "questState", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_description__ply_block.html#af0dbdcdc391dc368345c52878cb6aa5e", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_description__ply_block.html#a44dfeff797063ab9582df3f25340345f", null ]
];