var class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_timer =
[
    [ "OnDisable", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_timer.html#a617ac41e69c496e1adc0913fafd8cebd", null ],
    [ "StartCountdown", "class_pixel_crushers_1_1_dialogue_system_1_1_daikon_forge_g_u_i_1_1_daikon_forge_timer.html#a73fc86619ba106cdd3dbc4abdb6f2bf2", null ]
];