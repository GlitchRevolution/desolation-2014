var class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state =
[
    [ "ConversationState", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#a124332465bbe705fdc54f372a5afc509", null ],
    [ "npcResponses", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#a0c8dd15610723c2cb46167726bda65ca", null ],
    [ "pcResponses", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#a4220b727693b957005a2160b46f85469", null ],
    [ "subtitle", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#abe9cf8b0b2a7adb8f7bda6ca35899d49", null ],
    [ "FirstNPCResponse", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#a2576aee87e079b9fc981bf387d1cd6c9", null ],
    [ "HasAnyResponses", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#a21ce3eec374ef81835a3f57e481056d4", null ],
    [ "HasNPCResponse", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#ac011bd64e0406cfd6c36da7e66f1d28f", null ],
    [ "HasPCAutoResponse", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#ad12647a430fb63d1cef46129f65db906", null ],
    [ "HasPCResponses", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#abac4cc59596901d75aa8ae5595ace15f", null ],
    [ "IsGroup", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#a3679e56de7b741451ac8bddb206d6266", null ],
    [ "PCAutoResponse", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_state.html#ad6e8d1e1b00688c6e9038ef4198e9cd2", null ]
];