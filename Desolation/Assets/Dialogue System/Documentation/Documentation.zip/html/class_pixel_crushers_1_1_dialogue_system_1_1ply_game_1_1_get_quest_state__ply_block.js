var class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_state__ply_block =
[
    [ "Initialise", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_state__ply_block.html#a00dce998148d27965451e9b847cd6935", null ],
    [ "Run", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_state__ply_block.html#a00005bcce6030a2ab37921786c96f92b", null ],
    [ "title", "class_pixel_crushers_1_1_dialogue_system_1_1ply_game_1_1_get_quest_state__ply_block.html#a9aab228d99e84b3f1d17280a8feb3ec2", null ]
];