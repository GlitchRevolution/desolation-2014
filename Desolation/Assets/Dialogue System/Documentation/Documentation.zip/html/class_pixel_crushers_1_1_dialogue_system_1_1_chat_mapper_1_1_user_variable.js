var class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_user_variable =
[
    [ "Fields", "class_pixel_crushers_1_1_dialogue_system_1_1_chat_mapper_1_1_user_variable.html#ad5f711f6789030fae70dda349480f06e", null ]
];