var class_pixel_crushers_1_1_dialogue_system_1_1_conversation_starter =
[
    [ "TryStartConversation", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_starter.html#aaa930c13ec516c6db68e8b991490d26e", null ],
    [ "condition", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_starter.html#ae65dac854d99458d32d64da8cbf394f6", null ],
    [ "conversant", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_starter.html#afc5a58653ebf527fdefda6e6b1a0f7ba", null ],
    [ "conversation", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_starter.html#aa38a835b6936ad28402fd9c178ca0df3", null ],
    [ "skipIfNoValidEntries", "class_pixel_crushers_1_1_dialogue_system_1_1_conversation_starter.html#ac550eddabb8c4f9c833129145f51f625", null ]
];